const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../config/db'); // Pastikan path ini benar

// Fungsi Registrasi User Baru
exports.register = async (req, res) => {
    const { username, password } = req.body;

    // Validasi input
    if (!username || !password) {
        return res.status(400).json({ message: 'Username dan password wajib diisi!' });
    }

    try {
        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Simpan user ke database
        const query = 'INSERT INTO users (username, password) VALUES (?, ?)';
        db.query(query, [username, hashedPassword], (err, result) => {
            if (err) {
                if (err.code === 'ER_DUP_ENTRY') {
                    return res.status(400).json({ message: 'Username sudah digunakan!' });
                }
                return res.status(500).json({ message: 'Gagal registrasi!', error: err });
            }
            res.status(201).json({ message: 'Registrasi berhasil!' });
        });
    } catch (err) {
        res.status(500).json({ message: 'Ada kesalahan saat registrasi!', error: err.message });
    }
};

// Fungsi Login dan Generate Token
exports.login = (req, res) => {
    const { username, password } = req.body;

    // Validasi input
    if (!username || !password) {
        return res.status(400).json({ message: 'Username dan password wajib diisi!' });
    }

    // Cari user berdasarkan username
    const query = 'SELECT * FROM users WHERE username = ?';
    db.query(query, [username], async (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Ada kesalahan saat mencari user.', error: err.message });
        }

        // Jika user tidak ditemukan
        if (results.length === 0) {
            return res.status(404).json({ message: 'Username atau password salah!' });
        }

        const user = results[0];

        // Periksa password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Username atau password salah!' });
        }

        // Buat token JWT
        const token = jwt.sign(
            { userId: user.id, username: user.username },
            process.env.SECRET_KEY, // Pastikan SECRET_KEY sudah diatur di .env
            { expiresIn: '1h' }
        );

        res.status(200).json({ token, message: 'Login berhasil!' });
    });
};

// Middleware untuk Validasi Token
exports.verifyToken = (req, res, next) => {
    const authHeader = req.header('Authorization');
    if (!authHeader) {
        return res.status(403).json({ message: 'Token tidak ditemukan. Akses ditolak!' });
    }

    const token = authHeader.split(' ')[1]; // Mendapatkan token dari header Authorization

    if (!token) {
        return res.status(403).json({ message: 'Token tidak valid atau kosong!' });
    }

    try {
        const decoded = jwt.verify(token, process.env.SECRET_KEY); // Verifikasi token
        req.user = decoded; // Simpan data user dari token ke request
        next(); // Lanjut ke route berikutnya
    } catch (err) {
        res.status(401).json({ message: 'Token tidak valid!', error: err.message });
    }
};
